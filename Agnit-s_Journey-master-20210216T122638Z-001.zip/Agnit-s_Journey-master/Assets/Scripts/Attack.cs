﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attack : MonoBehaviour
{
    private bool attacking = false;
    private float attackTimer = 0.0f;
    private float attackCD = 0.5f;

    public Collider2D  attackTrigger;

    public Transform atrigger;

    public GameObject slash;
    public GameObject trigger;
    private GameObject cloneslash;

    private Animator animator;

    void Start()
    {
        animator = gameObject.GetComponent<Animator>();
        attackTrigger.enabled = !attackTrigger.enabled;
       

        
        
    }

    void FixedUpdate()
    {
        if(Input.GetKey(KeyCode.Z) && !attacking)
        {
            attacking = true;
            attackTimer = attackCD;
            attackTrigger.enabled = !attackTrigger.enabled;
            
            cloneslash = Instantiate(slash, atrigger.position, slash.transform.rotation);
            cloneslash.transform.parent = trigger.transform;
        }

        if (attacking)
        {

           
            if (attackTimer > 0)
            {
                attackTimer -= Time.deltaTime;

            }
            else if (attackTimer <= 0)
            {
                attackTrigger.enabled = !attackTrigger.enabled;
                attacking = false;

                GameObject.Destroy(cloneslash);

            }
        }
        animator.SetBool("Attack", attacking);
    }
}
