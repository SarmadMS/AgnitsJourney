﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HUD : MonoBehaviour
{
    public Sprite[] healthBar;

    public Image barUI;

    private Controls player;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Controls>();
    }

    void FixedUpdate()
    {
        barUI.sprite = healthBar[player.currHealth];
    }
}
