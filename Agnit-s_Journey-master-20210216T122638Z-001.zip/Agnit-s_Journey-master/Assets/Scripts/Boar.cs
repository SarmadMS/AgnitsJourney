﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boar : MonoBehaviour
{
    private int chealth = 30;
    public Animator animator;
    

    public float speed = 5f;
    public bool movingRight = false;
    public Transform groundDectection;
    public Transform target;
    




    // Start is called before the first frame update
    void Start()
    {
       
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {

      if (Vector2.Distance(transform.position, target.position) < 9)
        {
            
            transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime );

            
           


        }
        else {
        
        transform.Translate(Vector2.left * speed * Time.deltaTime);

        RaycastHit2D groundInfo = Physics2D.Raycast(groundDectection.position, Vector2.up, 9f);

        if(groundInfo.collider == false)
        {
           if(movingRight == false)
            {
                transform.eulerAngles = new Vector3(0, -180, 0);
                movingRight = true;
            } else
            {
                transform.eulerAngles = new Vector3(0,0, 0);
                movingRight = false;
            }
        }

            

            animator.SetFloat("Speed", Mathf.Abs(speed));
        }
        if (chealth <= 0)
        {
            Destroy(gameObject);
        }

        

    }

   

    public void Damage(int damage)
    {
        chealth -= damage;
        gameObject.GetComponent<Animation>().Play("DamageIndicator");


    }
}
