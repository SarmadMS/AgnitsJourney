﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Controls : MonoBehaviour
{

    public Animator animator;

    public float speed = 5.0f;
    private Rigidbody2D rBody;

    public Vector3 jump;
    public float jumpForce = 2.0f;

    public bool isGrounded;

    private bool isRight = false;

    public int currHealth;
    public int maxHealth = 100;
    // Start is called before the first frame update
    void Start()
    {

        rBody = GetComponent<Rigidbody2D>();
        jump = new Vector3(0.0f, 2.0f, 0.0f);
        currHealth = maxHealth;

    }
    void OnCollisionStay2D()
    {
        isGrounded = true;
    }
    // Update is called once per frame
    void Update()
    {
        

    }
     void FixedUpdate()
    {
        

        float horiz = Input.GetAxis("Horizontal");

        rBody.velocity = new Vector2(horiz * speed, rBody.velocity.y);

        if (Input.GetKey(KeyCode.UpArrow) && isGrounded)
        {
            rBody.velocity = new Vector2(rBody.velocity.x, jumpForce);
            isGrounded = false;
        }

        if(rBody.velocity.x > 0 && !isRight)
        {
            Flip();
        }
        else if(rBody.velocity.x < 0 && isRight)
        {
            Flip();
        }
        animator.SetFloat("Speed", Mathf.Abs(horiz));
        animator.SetBool("Grounded", isGrounded);

        if (currHealth <= 0)
        {
            Die();
        }
    }

    public void Damage(int dmg)
    {

        currHealth -= dmg;
        gameObject.GetComponent<Animation>().Play("DamageIndicator");


    }

    private void Flip()
    {
        isRight = !isRight;

        Vector3 tempScale = transform.localScale;
        tempScale.x *= -1;
        transform.localScale = tempScale;
    }

    private void Die()
    {
        SceneManager.LoadScene("SampleScene");
    }
    
}
